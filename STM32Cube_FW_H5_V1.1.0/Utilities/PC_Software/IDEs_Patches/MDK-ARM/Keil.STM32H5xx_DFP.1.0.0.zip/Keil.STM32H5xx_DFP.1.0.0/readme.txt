**
  ***************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32H5xx devices support on MDK-ARM.
  ***************************************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ****************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32H5xx 
  devices by MDK-ARM v5.34 and laters.

  Running the "Keil.STM32H5xx_DFP.1.0.0.pack" adds the following:
  ==============================================================
  
  1. Part numbers with 2MB Flash size: STM32H562xIxx / STM32H563xIxx / STM32H573xIxx

  2. Product line with 128kB Flash size:STM32H503xBxx

  3. Automatic STM32H5 flash algorithm selection

  4. H5 2M and H503 128Kb SVD files 


  How to use:
  ==========
 * Before installing the files mentioned above, you need to have MDK-ARM v5.34 or later installed. 
   You can download pack from keil web site @ www.keil.com
 
 * Double Clic on  "Keil.STM32H5xx_DFP.1.0.0.pack" in order to install this pack in 
   the Keil install directory.








	



